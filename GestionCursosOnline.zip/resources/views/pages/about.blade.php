@extends('layouts.app')

@section('content')
    <h1><?php echo $title;?></h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora, fugiat? Perferendis ipsam fugit aliquam soluta molestiae fuga, voluptatem quos sapiente nemo laboriosam maiores aut quod! Accusamus molestias ducimus ratione quidem?</p>
@endsection