<?php $__env->startSection('content'); ?>
    <br>
    <!-- <h1>Welcom to Laravel</h1>-->
    <h1 class="text-center"><?php echo $title;?></h1>
    
    <div class="jumbotron text-center">
        <p>Esta es una aplicación en línea para la inscripción de listas de cursos con respectivos roles</p>
        <div>
            
            
            
            <a class="btn btn-success btn-lg" href="<?php echo e(url('/register/estudiante')); ?>" role="button">Estudiante</a>
            <a class="btn btn-success btn-lg" href="<?php echo e(url('/register/profesor')); ?>" role="button">Profesor</a>
            
        </div>
    </div>
    </div>    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\GestionCursosOnline\resources\views/pages/index.blade.php ENDPATH**/ ?>