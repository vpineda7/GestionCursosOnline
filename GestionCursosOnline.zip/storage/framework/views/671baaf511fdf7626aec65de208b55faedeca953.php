<?php $__env->startSection('content'); ?>
    <h1><?php echo $title;?></h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora, fugiat? Perferendis ipsam fugit aliquam soluta molestiae fuga, voluptatem quos sapiente nemo laboriosam maiores aut quod! Accusamus molestias ducimus ratione quidem?</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\GestionCursosOnline\resources\views/pages/about.blade.php ENDPATH**/ ?>